using RBot;
using System;
using System.Collections.Generic;
using System.Linq;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StopTimer();
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.AggroMonsters = false;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		bot.Inventory.BankAllCoinItems();
		
		bot.Sleep(2000);
		
		bot.Bank.ToInventory("Aeacus Empowered");
		bot.Bank.ToInventory("Tethered Soul");
		bot.Bank.ToInventory("Darkened Essence");
		bot.Bank.ToInventory("Dracolich Contract");
		bot.Bank.ToInventory("Revenant's Spellscroll");
		
		bot.Bank.ToInventory("Void Highlord");
		bot.Bank.ToInventory("Blaze Binder");
		
		while(!bot.Inventory.Contains("Revenant's Spellscroll", 20)){
			bot.Quests.EnsureAccept(6897);
			
			bot.Options.HuntBuffer = 1;
			bot.Player.JoinGlitched("judgement");
			bot.Player.EquipItem("Void Highlord");
			bot.Skills.LoadSkills("Skills/VoidHighlord.xml");
			bot.Skills.StartTimer();
			bot.Player.HuntForItem("Ultra Aeacus", "Aeacus Empowered", 50);
			
			bot.Sleep(2000);
			
			bot.Bank.ToInventory("Infinite Legion Dark Caster");
			bot.Player.Join("revenant");
			bot.Player.HuntForItem("Forgotten Soul", "Tethered Soul", 300);
			
			bot.Sleep(2000);
			
			bot.Options.HuntBuffer = 2;
			bot.Player.Join("shadowrealm");
			bot.Player.EquipItem("Blaze Binder");
			bot.Skills.LoadSkills("Skills/Generic.xml");
			bot.Skills.StartTimer();
			bot.Player.HuntForItem("Pure Shadowscythe|Shadow Guardian|Shadow Warrior", "Darkened Essence", 500);
			
			bot.Sleep(2000);
			
			bot.Player.Join("necrodungeon");
			bot.Sleep(1000);
			bot.Options.AggroMonsters = true;
			bot.Player.HuntForItem("5 Headed Dracolich", "Dracolich Contract", 1000);
			bot.Options.AggroMonsters = false;
			
			bot.Quests.EnsureComplete(6897);
			bot.Wait.ForDrop("Revenant's Spellscroll");
			bot.Player.Pickup("Revenant's Spellscroll");
		}
	}
}