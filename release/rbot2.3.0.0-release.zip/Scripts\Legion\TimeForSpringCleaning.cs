using RBot;
using System;
using System.Collections.Generic;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.LoadBank();
		bot.Inventory.BankAllCoinItems();
		
		bot.Sleep(2000);
		
		bot.Bank.ToInventory("Legion Token");
		
		bot.Player.Join("fotia");
		
		bot.Quests.EnsureAccept(5753);
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(5755);
			
			bot.Player.HuntForItems("Femme Cult Worshiper|Fotia Elemental|Fotia Spirit", (new List<string>() { "Nothing Heard", "Nothing To See", "Area Secured and Quiet", "Fotia Spirit Extinguished", "Fotia Elemental Vanquished", "Femme Cult Worshipper's Soul" }).ToArray(), (new List<int>() { 10, 10, 10, 1, 1, 1 }).ToArray(), true);
			
			bot.Quests.EnsureComplete(5755);
			if(bot.Quests.CanComplete(5753)){
				bot.Quests.EnsureComplete(5753);
				bot.Quests.EnsureAccept(5753);
			}
			
			bot.Wait.ForDrop("Legion Token");
			bot.Player.Pickup("Legion Token");
		}
	}
}