using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntDelay = 1800;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Necrotic Scythe of Scourge");
		bot.Runtime.Require("Corrupt Spirit Orb");
		bot.Runtime.Require("Ominous Aura");
		bot.Runtime.Require("Doom Aura");
		
		bot.Player.JoinGlitched("poisonforest");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2184);
			
			bot.Player.HuntForItem("Traitor Knight|Traitor Lieutenant", "DoomKnight Armor Piece", 10, true);
			
			bot.Quests.EnsureComplete(2184);
			bot.Wait.ForDrop("Corrupt Spirit Orb");
			bot.Player.Pickup("Corrupt Spirit Orb", "Ominous Aura", "Doom Aura");
		}
	}
}
