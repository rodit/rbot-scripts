using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		
		bot.Events.PlayerAFK += b => {
			try{
				ScriptManager.StopScript();
				bot.Player.Jump("Blank", "Spawn");
				bot.Player.Logout();
			}catch{}
		};
	
		bot.Skills.StartTimer();
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Sepulchure's DoomKnight Armor");
		bot.Runtime.Require("Empowered Essence");
		bot.Runtime.Require("Malignant Essence");
		bot.Runtime.Require("Void Aura");
		
		bot.Player.JoinGlitched("shadowrealm");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(4439);
			
			bot.Options.HuntBuffer = 5;
			
			bot.Player.EquipItem("Dual Blinding Light of Destiny");
			bot.Player.EquipItem("Legion Revenant");
			bot.Skills.StartSkills("Skills/Generic.xml");
			bot.Player.HuntForItem("Pure Shadowscythe|Shadow Guardian|Shadow Warrior", "Empowered Essence", 50);

			bot.Options.HuntBuffer = 1;
			
			bot.Player.Jump("Blank", "Spawn");
			bot.Sleep(2000);
			bot.Player.EquipItem("Blinding Light of Destiny");
			bot.Player.EquipItem("Void Highlord");
			bot.Skills.StartSkills("Skills/VoidHighlord.xml");
			bot.Player.HuntForItem("Shadow Lord", "Malignant Essence", 3);
			
			bot.Quests.EnsureComplete(4439);
			bot.Wait.ForDrop("Void Aura");
			bot.Player.Pickup("Void Aura");
			bot.Player.RejectExcept("Void Aura");
		}
	}
}