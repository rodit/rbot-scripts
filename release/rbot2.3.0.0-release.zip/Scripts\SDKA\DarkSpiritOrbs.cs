using RBot;
using System;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntDelay = 2500;
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2065);
			
			if(!bot.Inventory.Contains("Shadow Creeper Enchant")){
				bot.Player.Join("bludrut2");
				bot.Player.HuntForItem("Shadow Creeper", "Shadow Creeper Enchant", 1);
			}
			
			if(!bot.Inventory.Contains("Shadow Serpent Scythe")){
				bot.Player.Join("bludrut4");
				bot.Player.HuntForItem("Shadow Serpent", "Shadow Serpent Scythe", 1);
			}
			
			if(!bot.Inventory.ContainsTempItem("Shadow Whiskers", 6)){
				bot.Player.Join("ruins");
				bot.Player.HuntForItem("Dark Witch", "Shadow Whiskers", 6, true);
			}
			
			bot.Quests.EnsureComplete(2065);
			
			bot.Wait.ForDrop("Dark Spirit Orb");
			bot.Player.Pickup("Dark Spirit Orb");
		}
	}
}