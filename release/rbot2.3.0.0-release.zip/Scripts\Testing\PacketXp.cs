using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Player.Join("brightfortress");

		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(4456);
			bot.Map.GetMapItem(3649);
			bot.Sleep(300);
			bot.Quests.EnsureComplete(4456);
		}
	}
}