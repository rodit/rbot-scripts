using RBot;
using RBot.Strategy;
using System.Windows.Forms;

public class Script
{

    public void ScriptMain(ScriptInterface bot)
    {
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		
		bot.Skills.StartTimer();
		
		DefinitionLoader.RunDefinition(bot, "Scripts/Strategy/nwno.def");
    }
}