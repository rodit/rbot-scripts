using System;
using System.Collections.Generic;

using RBot;
using RBot.Options;

public class Script{

	public string OptionsStorage = "test";

	public List<IOption> Options = new List<IOption>() {
		new Option<bool>("test1", "Test Option 1", "This is a test option (1).", true),
		new Option<HuntPriorities>("enum1", "Test Option 2", "This is a test option (2)")
	};

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Log(bot.Config.Get<bool>("test1") + "");
		bot.Log(bot.Config.Get<HuntPriorities>("enum1") + "");
	}
}
