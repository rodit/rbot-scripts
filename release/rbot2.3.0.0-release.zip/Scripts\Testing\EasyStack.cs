using RBot;
using System.Collections.Generic;
using System.Linq;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.InfiniteRange = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Options.HuntPriority = HuntPriorities.Close;
		bot.Options.HuntBuffer = 5;
		
		bot.Player.LoadBank();
		
		bot.Runtime.Require("Undead Energy");
		bot.Runtime.Require("Undead Essence");
		bot.Runtime.Require("Bone Dust");
		
		bot.Inventory.BankAllCoinItems();
		
		bot.Skills.StartTimer();
        
        while(!bot.ShouldExit()){
        	bot.Player.Join("battleunderb");
        	
        	bot.Player.HuntForItems("Skeleton Warrior|Skeleton Fighter", (new List<string>() { "Bone Dust", "Undead Essence", "Undead Energy" }).ToArray(), (new List<int>() { 5100, 1000, 10000 }).ToArray());
        }
	}
}
