using RBot;
using System;
using System.Collections.Generic;
using System.Linq;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		
		bot.Runtime.Require("Hooded Legion Cowl");
		bot.Runtime.Require("Legion Token");
		bot.Runtime.Require("Dage's Favor");
		bot.Runtime.Require("Emblem of Dage");
		bot.Runtime.Require("Diamond Token of Dage");
		bot.Runtime.Require("Dark Token");
		bot.Runtime.Require("Exalted Crown");
		
		bot.Runtime.Require("Void Highlord");
		bot.Runtime.Require("Blaze Binder");
		
		bot.Inventory.BankAllCoinItems();
		
		bot.Shops.Load(216);
		
		while(!bot.Inventory.Contains("Exalted Crown", 10)){
			bot.Quests.EnsureAccept(6899);
			
			bot.Player.EquipItem("Void Highlord");
			bot.Skills.StartSkills("Skills/VoidHighlord.xml");
			
			bot.Options.HuntDelay = 4000;
			if(!bot.Inventory.Contains("Legion Token", 4000))
				LegionToken(bot, 4000);
			
			bot.Options.HuntBuffer = 5;
			bot.Options.HuntDelay = 4000;
			if(!bot.Inventory.Contains("Dage's Favor", 300)){
				bot.Player.Join("evilwardage");
				bot.Player.HuntForItem("Bloodfiend|Dark Makai|Infernalfiend|Skull Warrior", "Dage's Favor", 300);
			}
			
			bot.Options.HuntDelay = 2500;
			bot.Options.HuntBuffer = 1;
			if(!bot.Inventory.Contains("Emblem of Dage"))
				EmblemOfDage(bot, 1);
			
			if(!bot.Inventory.Contains("Diamond Token of Dage", 30))
				DiamondToken(bot, 30);
			
			bot.Player.EquipItem("Blaze Binder");
			bot.Skills.StartSkills("Skills/Generic.xml");
			if(!bot.Inventory.Contains("Dark Token", 100))
				DarkToken(bot, 100);
			
			if(!bot.Inventory.Contains("Hooded Legion Cowl"))
				bot.Shops.BuyItem(216, "Hooded Legion Cowl");
			
			bot.Quests.EnsureComplete(6899);
			bot.Wait.ForDrop("Exalted Crown");
			bot.Player.Pickup("Exalted Crown");
		}
	}
	
	public void LegionToken(ScriptInterface bot, int quantity){
		bot.Player.Join("fotia");
		
		bot.Quests.EnsureAccept(5753);
		
		while(!bot.Inventory.Contains("Legion Token", quantity)){
			bot.Quests.EnsureAccept(5755);
			
			bot.Player.HuntForItems("Femme Cult Worshiper|Fotia Elemental|Fotia Spirit", (new List<string>() { "Nothing Heard", "Nothing To See", "Area Secured and Quiet", "Fotia Spirit Extinguished", "Fotia Elemental Vanquished", "Femme Cult Worshipper's Soul" }).ToArray(), (new List<int>() { 10, 10, 10, 0, 0, 0 }).ToArray(), true);
			
			bot.Quests.EnsureComplete(5755);
			if(bot.Quests.CanComplete(5753)){
				bot.Quests.EnsureComplete(5753);
				bot.Quests.EnsureAccept(5753);
			}
			
			bot.Wait.ForDrop("Legion Token");
			bot.Player.Pickup("Legion Token");
			bot.Player.RejectExcept("Legion Token");
		}
	}
	
	public void EmblemOfDage(ScriptInterface bot, int quantity){
		bot.Player.Join("shadowblast");
		
		bot.Bank.ToInventory("Legion Seal");
		bot.Bank.ToInventory("Gem of Mastery");
		
		while(!bot.Inventory.Contains("Emblem of Dage", quantity)){
			bot.Quests.EnsureAccept(4742);
			
			bot.Player.HuntForItem("CaesarisTheDark|Carnage|Minotaurofwar", "Gem of Mastery", 1);
			bot.Player.HuntForItem("DoomBringer|DoomKnight Prime|Draconic DoomKnight|Shadowrise Guard", "Legion Seal", 25);
			
			bot.Quests.EnsureComplete(4742);
			bot.Wait.ForDrop("Emblem of Dage");
			bot.Player.Pickup("Emblem of Dage");
		}
	}
	
	public void DiamondToken(ScriptInterface bot, int quantity){
		bot.Bank.ToInventory("Defeated Makai");
		
		while(!bot.Inventory.Contains("Diamond Token of Dage", quantity)){
            bot.Quests.EnsureAccept(4743);
            
		    bot.Player.Join("citadel");
		    bot.Player.Jump("m22", "Left");
	        bot.Player.Join("tercessuinotlim", "Enter", "Spawn");
            bot.Player.HuntForItem("Dark Makai", "Defeated Makai", 25);
            
            bot.Player.Join("aqlesson");
            bot.Player.HuntForItem("Carnax", "Carnax Eye", 1, true);
            
            bot.Player.Join("deepchaos");
            bot.Player.HuntForItem("Kathool", "Kathool Tentacle", 1, true);
            
            bot.Player.Join("lair");
            bot.Player.HuntForItem("Red Dragon", "Red Dragon's Fang", 1, true);
            
            bot.Player.Join("dflesson");
            bot.Player.HuntForItem("Fluffy The Dracolich", "Fluffy's Bones", 1, true);
            
            bot.Player.Join("bloodtitan");
            bot.Player.HuntForItem("Blood Titan", "Blood Titan's Blade", 1, true);
            
            bot.Quests.EnsureComplete(4743);
            bot.Wait.ForDrop("Diamond Token of Dage");
            bot.Player.Pickup("Diamond Token of Dage", "Legion Token");
		}
	}
	
	public void DarkToken(ScriptInterface bot, int quantity){
		bot.Player.Join("seraphicwardage");
		bot.Quests.EnsureAccept(6249);
		bot.Quests.EnsureAccept(6251);
		bot.Options.ExitCombatBeforeQuest = false;
		while(!bot.Inventory.Contains("Dark Token", quantity)){
			bot.Quests.EnsureAccept(6248);
			
			bot.Player.HuntForItem("Seraphic Soldier|Seraphic Commander", "Seraphic Medals", 10, true);
			
			bot.Player.Jump("Enter", "Spawn");
			
			while(bot.Quests.CanComplete(6248)){
				bot.Quests.Complete(6248);
				if(bot.Quests.IsInProgress(6248))
					break;
				bot.Quests.EnsureAccept(6248);
			}
			
			while(bot.Quests.CanComplete(6249)){
				bot.Quests.Complete(6249);
				if(bot.Quests.IsInProgress(6249))
					break;
				bot.Quests.EnsureAccept(6249);
			}
			
			while(bot.Quests.CanComplete(6251)){
				bot.Quests.Complete(6251);
				if(bot.Quests.IsInProgress(6251))
					break;
				bot.Quests.EnsureAccept(6251);
			}
			
			bot.Wait.ForDrop("Dark Token");
			bot.Player.Pickup("Dark Token");
		}
		bot.Options.ExitCombatBeforeQuest = true;
	}
}