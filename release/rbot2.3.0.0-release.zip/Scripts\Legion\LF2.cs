using RBot;
using System;
using System.Collections.Generic;
using System.Linq;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StopTimer();
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		bot.Options.HuntDelay = 3500;
		bot.Options.HuntBuffer = 4;
		
		bot.Player.LoadBank();
		bot.Inventory.BankAllCoinItems();
		
		bot.Sleep(2000);
		
		bot.Bank.ToInventory("Grim Cohort Conquered");
		bot.Bank.ToInventory("Ancient Cohort Conquered");
		bot.Bank.ToInventory("Pirate Cohort Conquered");
		bot.Bank.ToInventory("Battleon Cohort Conquered");
		bot.Bank.ToInventory("Mirror Cohort Conquered");
		bot.Bank.ToInventory("Darkblood Cohort Conquered");
		bot.Bank.ToInventory("Vampire Cohort Conquered");
		bot.Bank.ToInventory("Spirit Cohort Conquered");
		bot.Bank.ToInventory("Dragon Cohort Conquered");
		bot.Bank.ToInventory("Doomwood Cohort Conquered");
		bot.Bank.ToInventory("Conquest Wreath");
		
		bot.Bank.ToInventory("Void Highlord");
		bot.Bank.ToInventory("Blaze Binder");
		
		while(!bot.Inventory.Contains("Conquest Wreath", 6)){
			bot.Quests.EnsureAccept(6898);
			
			bot.Player.EquipItem("Blaze Binder");
			bot.Skills.LoadSkills("Skills/Generic.xml");
			bot.Skills.StartTimer();
			
			if(!bot.Inventory.Contains("Grim Cohort Conquered", 500)){
				bot.Player.JoinGlitched("doomvault");
				bot.Player.HuntForItem("Fallen Emperor Statue|Fallen Light Statue|Grim Ectomancer|Grim Fighter|Grim Fire Mage|Grim Lich|Grim Soldier|Grim Souldier", "Grim Cohort Conquered", 500);
			}
			
			if(!bot.Inventory.Contains("Ancient Cohort Conquered", 500)){
				bot.Player.Join("mummies");
				bot.Player.HuntForItem("Mummy", "Ancient Cohort Conquered", 500);
			}
			
			if(!bot.Inventory.Contains("Pirate Cohort Conquered", 500)){
				bot.Player.Join("wrath");
				bot.Player.HuntForItem("Dark Fire|Fishbones|Undead Pirate|Mutineer|Bone Terror", "Pirate Cohort Conquered", 500);
			}
			
			if(!bot.Inventory.Contains("Battleon Cohort Conquered", 500)){
				bot.Player.Join("doomwar");
				bot.Player.HuntForItem("Zombie Knight|Zombie", "Battleon Cohort Conquered", 500);
			}
			
			if(!bot.Inventory.Contains("Mirror Cohort Conquered", 500)){
				bot.Player.Join("overworld");
				bot.Player.HuntForItem("Undead Bruiser|Undead Mage|Undead Minion", "Mirror Cohort Conquered", 500);
			}
			
			bot.Options.HuntDelay = 5000;
			if(!bot.Inventory.Contains("Darkblood Cohort Conquered", 500)){
				bot.Player.JoinGlitched("deathpits");
				bot.Player.HuntForItem("Rotting Darkblood|Ghastly Darkblood|Sundered Darkblood", "Darkblood Cohort Conquered", 500);
			}
			bot.Options.HuntDelay = 3500;
			
			if(!bot.Inventory.Contains("Vampire Cohort Conquered", 500)){
				bot.Player.Join("maxius");
				bot.Player.HuntForItem("Vampire Minion|Ghoul Minion", "Vampire Cohort Conquered", 500);
			}
			
			bot.Player.EquipItem("Void Highlord");
			bot.Skills.LoadSkills("Skills/VoidHighlord.xml");
			bot.Skills.StartTimer();
			
			if(!bot.Inventory.Contains("Spirit Cohort Conquered", 500)){
				bot.Player.JoinGlitched("curseshore");
				bot.Player.HuntForItem("Escaped Ghostly Zardman|Escaped Wendighost|Escaped Dai Tenghost", "Spirit Cohort Conquered", 500);
			}
			
			bot.Player.EquipItem("Blaze Binder");
			bot.Skills.LoadSkills("Skills/Generic.xml");
			bot.Skills.StartTimer();
			
			if(!bot.Inventory.Contains("Dragon Cohort Conquered", 500)){
				bot.Player.Join("dragonbone");
				bot.Player.HuntForItem("Bone Dragonling|Dark Fire", "Dragon Cohort Conquered", 500);
			}
			
			if(!bot.Inventory.Contains("Doomwood Cohort Conquered", 500)){
				bot.Player.JoinGlitched("doomwood");
				bot.Player.HuntForItem("Doomwood Bonemuncher|Doomwood Ectomancer|Doomwood Soldier|Doomwood Treeant", "Doomwood Cohort Conquered", 500);
			}
			
			bot.Quests.EnsureComplete(6898);
			bot.Wait.ForDrop("Conquest Wreath");
			bot.Player.Pickup("Conquest Wreath");
		}
	}
}