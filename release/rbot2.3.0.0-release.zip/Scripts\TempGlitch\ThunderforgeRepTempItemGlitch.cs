using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.Join("deathpits");
		bot.Quests.EnsureAccept(2733);
		bot.Player.HuntForItem("Wrathful Vestis", "Vestis's Chaos Eye", 1, true);
		bot.Player.AddTempItem(16473, 100000);
		bot.Player.Jump("Spawn", "Enter");
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2733);
			bot.Quests.EnsureComplete(2733);
		}
	}
}
