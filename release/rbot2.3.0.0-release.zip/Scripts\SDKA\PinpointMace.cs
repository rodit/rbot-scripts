using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntDelay = 3500;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Necrotic Mace of Misery");
		bot.Runtime.Require("Dark Spirit Orb");
		bot.Runtime.Require("Ominous Aura");
		bot.Runtime.Require("Doom Aura");
		bot.Runtime.Require("Dark Energy");
		
		if(bot.Map.Name != "tercessuinotlim"){
			bot.Player.Join("citadel");
			bot.Player.Jump("m22", "Left");
			bot.Sleep(2000);
			bot.Player.JoinGlitched("tercessuinotlim");
		}
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2185);
			
			bot.Player.HuntForItem("Dark Makai", "DoomKnight Armor Piece", 10, true);
			
			bot.Player.Jump("Blank", "Spawn");
			bot.Sleep(500);
			bot.Quests.EnsureComplete(2185);
			bot.Wait.ForDrop("Ominous Aura");
			bot.Player.Pickup("Ominous Aura", "Dark Spirit Orb", "Dark Energy", "Doom Aura");
			bot.Player.RejectExcept("Ominous Aura", "Dark Spirit Orb", "Dark Energy", "Doom Aura");
		}
	}
}
