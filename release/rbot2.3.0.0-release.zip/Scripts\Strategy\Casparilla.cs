using RBot;
using RBot.Strategy;
using System.Windows.Forms;

public class Script
{

    public void ScriptMain(ScriptInterface bot)
    {
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		
		bot.Skills.StartTimer();
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Boss Zardman")
				.Item("One Spiky Boy")
				.Temp()
				.Room("forest")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Shadow Creeper")
				.Item("New Disguise")
				.Temp()
				.Room("bludrut2")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Thrax Ironhide")
				.Item("Large Piece of Armor")
				.Temp()
				.Room("marsh2")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Harmoire")
				.Item("A Fancy, Shmancy New Outfit")
				.Temp()
				.Room("sleuthhound")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Kittarian Mouse Eater")
				.Item("Small Bowl-shaped Eating Tool")
				.Temp()
				.Room("noobshire")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Princess Angler")
				.Item("Your Princess is Not in This Castle")
				.Temp()
				.Room("doomvault")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Beach Ball")
				.Item("Ready for the Beach")
				.Temp()
				.Room("lunacove")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Dreadspider")
				.Item("Crawly Leg")
				.Temp()
				.Room("marsh")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Enfield")
				.Item("Big Fluffy Doggo")
				.Temp()
				.Room("iceplane")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Red Dragon")
				.Item("Limited Time Drop")
				.Temp()
				.Room("lair")
				.Build());
		
		new QuestStrategy.Builder()
				.Quest(6669)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6671)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6672)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6673)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6674)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6675)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6676)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6677)
				.Build()
				.Obtain(bot);
		
		new QuestStrategy.Builder()
				.Quest(6678)
				.Build()
				.Obtain(bot);
				
		bot.Quests.EnsureAccept(6679);
		SmartBot.ObtainItem(bot, "Limited Time Drop", 1);
		
    }
}
