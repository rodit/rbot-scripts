using RBot;
using System.Windows.Forms;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.RestPackets = true;
		bot.Options.SafeTimings = true;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Burning Blade Of Abezeth");
		
		bot.Player.HuntForItem("Aranx", "Burning Blade Of Abezeth", 1);
	}
}
