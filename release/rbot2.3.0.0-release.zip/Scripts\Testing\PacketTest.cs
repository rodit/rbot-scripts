using RBot;

using System.Dynamic;
using Newtonsoft.Json;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.SendPacket("%xt%zm%guild%1%gc% Praise the Sun %");
	}
}