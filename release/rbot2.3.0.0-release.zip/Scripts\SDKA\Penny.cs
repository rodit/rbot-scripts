using RBot;
using System;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntDelay = 5000;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Dark Spirit Orb");
		bot.Runtime.Require("Undead Energy");
		
		bot.Player.JoinGlitched("maul");
		bot.Player.Jump("r5", "Left");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2089);
			
			bot.Player.HuntForItem("Personal Chopper|Shelleton|Slimeskull", "DoomCoin", 1, true, false);
			
			bot.Quests.EnsureComplete(2089);
			
			bot.Wait.ForDrop("Dark Spirit Orb");
			bot.Player.Pickup("Dark Spirit Orb", "Undead Energy");
			bot.Player.RejectExcept("Dark Spirit Orb", "Undead Energy");
		}
	}
}