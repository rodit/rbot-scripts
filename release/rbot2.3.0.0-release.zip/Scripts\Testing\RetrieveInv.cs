using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.GameProxy.Interceptors.Clear();
		bot.GameProxy.Interceptors.Add(new RetrieveInvInterceptor());		
	}
}

public class RetrieveInvInterceptor : Interceptor{

	public int Priority { get; } = 1;
	
	bool _first = true;
	
	public void Intercept(MessageInfo info, bool outbound){
		if(_first){
			if(info.Content.Contains("retrieveInventory")){
				_first = false;
				info.Send = false;
			}
		}
	}
}
