using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.LoadBank();
		
		bot.Quests.EnsureAccept(7156);
		
		PristineBlades(bot);
		LegionReceipt(bot);
		Banshee(bot);
		RavenscarTruth(bot);

		bot.Quests.EnsureComplete(7156);
		
		bot.Wait.ForDrop("Lord of Order Bladed Wrap");
		bot.Player.Pickup("Lord of Order Bladed Wrap", "Lord of Order Wrap");
		bot.Wait.ForPickup("Lord of Order Bladed Wrap");
		bot.Inventory.ToBank("Lord of Order Bladed Wrap");
		bot.Inventory.ToBank("Lord of Order Wrap");
		
		bot.Quests.EnsureAccept(7157);
		
		bot.Player.Join("dwarfprison");
		bot.Player.HuntForItem("Warden Elfis", "Warden Elfis Detained", 1);
		
		bot.Player.Join("prison");
		bot.Player.HuntForItem("Piggy Drake", "Piggy Drake Punished", 1);
		
		bot.Player.Join("mysteriousdungeon");
		bot.Player.HuntForItem("Mysterious Stranger", "Mysterious Stranger Foiled", 1);
		
		bot.Player.Join("dreammaster");
		bot.Player.HuntForItem("Calico Cobby", "Calico Cobby Crushed", 1);
		
		bot.Quests.EnsureComplete(7157);
		
		bot.Wait.ForDrop("Lord of Order Wings + Wrap");
		bot.Player.Pickup("Lord of Order Wings + Wrap", "Lord of Order Wings");
		bot.Wait.ForPickup("Lord of Order Wings + Wrap");
		bot.Inventory.ToBank("Lord of Order Wings + Wrap");
		bot.Inventory.ToBank("Lord of Order Wings");
		
		bot.Quests.EnsureAccept(7158);
		
		bot.Player.Join("hydra");
		bot.Player.HuntForItem("Hydra Head", "Chaoroot", 15);
		
		bot.Player.Join("chaosboss");
		bot.Player.HuntForItem("Ultra Chaos Warrior", "Chaotic War Essence", 15);
		
		bot.Player.Join("shadowgates");
		bot.Player.HuntForItem("Chaorruption", "Chaorrupting Particles", 15);
		
		bot.Player.Join("stormtemple");
		bot.Player.HuntForItem("Chaos Lord Lionfang", "Purified Raindrop", 45);
		
		bot.Quests.EnsureComplete(7158);
		
		bot.Wait.ForDrop("Lord of Order Double Wings + Wrap");
		bot.Player.Pickup("Lord of Order Double Wings + Wrap");
		bot.Wait.ForPickup("Lord of Order Double Wings + Wrap");
		bot.Inventory.ToBank("Lord of Order Double Wings + Wrap");
	}
	
	public void PristineBlades(ScriptInterface bot){
		if(bot.Inventory.Contains("Pristine Blades of Order"))
			return;
			
		bot.Player.Join("watchtower");
		bot.Player.HuntForItem("Chaorrupted Knight|Chaos Knight", "Pristine Blades of Order", 1);
	}
	
	public void LegionReceipt(ScriptInterface bot){
		if(bot.Inventory.Contains("Dreadrock Donation Receipt"))
			return;
		
		bot.Player.Join("dreadrock");
		bot.Shops.Load(1221);
		bot.Shops.BuyItem(1221, "Dreadrock Donation Receipt"); 
	}
	
	public void Banshee(ScriptInterface bot){
		if(bot.Inventory.Contains("Deadmoor Spirits Helped"))
			return;
		
		bot.Player.Join("deadmoor");
		bot.Player.HuntForItem("Banshee Mallora", "Deadmoor Spirits Helped", 1);
	}
	
	
	
	public void RavenscarTruth(ScriptInterface bot){
		if(bot.Inventory.Contains("Ravenscar's Truth"))
			return;
		
		bot.Player.Join("ravenscar");
		bot.Shops.Load(614);
		bot.Shops.BuyItem(614, "Ravenscar's Truth"); 
	}
}
