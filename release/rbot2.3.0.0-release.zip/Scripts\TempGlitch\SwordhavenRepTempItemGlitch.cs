using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Skills.StartTimer();
		
		bot.Player.Join("ultraalteon");
		bot.Quests.EnsureAccept(3161);
		bot.Player.HuntForItem("Ultra Alteon", "Ultra Chaos Lord Alteon Slain", 1, true);
		bot.Player.AddTempItem(20733, 100000);
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(3161);
			bot.Quests.EnsureComplete(3161);
		}
	}
}
