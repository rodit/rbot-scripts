using RBot;
using System.Collections.Generic;
using System.Linq;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = false;
		
		while(!bot.ShouldExit()){
			bot.Player.Jump("Enter", "Spawn");
			bot.Sleep(20000);
			bot.Player.Jump("Blank", "Spawn");
			bot.Sleep(20000);
		}
	}
}
