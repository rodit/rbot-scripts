using RBot;
using System;
using System.Collections.Generic;
using System.Linq;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.LoadBank();
		bot.Inventory.BankAllCoinItems();
		
		bot.Sleep(2000);
		
		bot.Bank.ToInventory("Legion Token");
		
		bot.Player.Join("evilwardage");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2246);
			
			string[] items = (new List<string>() { "Bloodfiend Eyes", "Dage's Approval", "Dage's Favor" }).ToArray();
			bot.Player.HuntForItems("Bloodfiend", items, (new List<int>() { 50, 1, 1 }).ToArray());
			bot.Player.HuntForItems("Bloodfiend|Dreadfiend of Nulgath|Infernalfiend", items, (new List<int>() { 50, 50, 50 }).ToArray());
			
			bot.Quests.EnsureComplete(2246);
			bot.Wait.ForDrop("Legion Token");
			bot.Player.Pickup("Legion Token");
		}
	}
}