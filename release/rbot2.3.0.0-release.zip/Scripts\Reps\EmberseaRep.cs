using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Player.Join("feverfew");

		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(4135);
			bot.SendPacket("%xt%zm%getMapItem%6896%3248%");
			bot.Sleep(300);
			bot.Quests.EnsureComplete(4135);
		}
	}
}