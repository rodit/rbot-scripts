using RBot;
using System.Collections.Generic;
using System.Linq;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.InfiniteRange = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntBuffer = 5;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Undead Energy");
		bot.Inventory.BankAllCoinItems();
		
		bot.Skills.StartTimer();
        
        while(!bot.ShouldExit()){
        	bot.Player.Join("doomwood");
        	
        	bot.Player.HuntForItem("Doomwood Bonemuncher|Doomwood Ectomancer|Doomwood Soldier|Doomwood Soldier", "Undead Energy", 1000);
        }
	}
}
