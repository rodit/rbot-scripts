using RBot;
using System;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("DoomSquire Weapon Kit");
		bot.Runtime.Require("Iron Hammer");
		bot.Runtime.Require("War Mummy Wrap");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2144);
			
			if(!bot.Inventory.Contains("Iron Hammer")){
				bot.Player.Join("swordhaven");
				bot.Shops.Load(179);
				bot.Sleep(5000);
				bot.Shops.BuyItem(179, "Iron Hammer");
			}
			
			if(!bot.Inventory.Contains("War Mummy Wrap")){
				bot.Player.Join("sandcastle");
				bot.Player.HuntForItem("War Mummy", "War Mummy Wrap", 1);
			}
			
			bot.Player.Join("noobshire");
			bot.Player.HuntForItem("Horc Noob", "Noob Blade Oil", 1, true);
			
			bot.Player.Join("lair");
			bot.Player.HuntForItem("Bronze Draconian", "Bronze Brush", 1, true);
			
			bot.Player.Join("farm");
			bot.Player.HuntForItem("Scarecrow", "Burlap Cloth", 4, true);
			
			bot.Player.Join("bludrut");
			bot.Player.HuntForItem("Rock Elemental", "Elemental Stone Sharpener", 1, true);
			
			bot.Player.Join("evilmarsh");
			bot.Player.HuntForItem("Dark Makai", "Dark Makai Lacquer Finish", 1, true);
			
			bot.Quests.EnsureComplete(2144);
			bot.Wait.ForDrop("DoomSquire Weapon Kit");
			bot.Player.Pickup("DoomSquire Weapon Kit");
		}
	}
}