using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Player.Join("mysteriousdungeon");

		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(5438);
			bot.Map.GetMapItem(4818);
			bot.Sleep(200);
			bot.Quests.EnsureComplete(5438);
		}
	}
}