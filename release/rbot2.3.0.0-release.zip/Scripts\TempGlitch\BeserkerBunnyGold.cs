using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = false;
		
		bot.Skills.StartTimer();
		
		bot.Player.Join("greenguardwest");
		bot.Quests.EnsureAccept(236);
		bot.Player.HuntForItem("Big Bad Boar", "Were Egg", 1, true);
		bot.Player.AddTempItem(1051, 100000);
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(236);
			bot.Quests.EnsureComplete(236);
			bot.Wait.ForDrop("Berserker Bunny");
			bot.Player.Pickup("Berserker Bunny");
			bot.Shops.SellItem("Berserker Bunny");
		}
	}
}
