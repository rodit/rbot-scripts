using RBot;
using RBot.Strategy;

public class TercessuinotlimNavigator : Navigator
{
	public override void Navigate(ScriptInterface bot){
		bot.Player.Join("citadel", "m22", "Right");
		bot.Player.Join("tercessuinotlim", "Enter", "Spawn");
	}
}