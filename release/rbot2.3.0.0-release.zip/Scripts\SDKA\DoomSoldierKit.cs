using RBot;
using System;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("DoomSoldier Weapon Kit");
		bot.Runtime.Require("Stone Hammer");
		
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2164);
			
			if(!bot.Inventory.Contains("Stone Hammer")){
				bot.Player.Join("cornelis");
				bot.Player.HuntForItem("Stone Golem", "Stone Hammer", 1);
			}
			
			bot.Player.Join("hachiko");
			bot.Player.HuntForItem("Dai Tengu", "Superior Blade Oil", 1, true);
			
			bot.Player.Join("pines");
			bot.Player.HuntForItem("Leatherwing", "Leatherwing Hide", 10, true);
			
			bot.Player.Join("lycan");
			bot.Player.HuntForItem("Chaos Vampire Knight", "Silver Brush", 1, true);
			
			bot.Player.Join("sandport");
			bot.Player.HuntForItem("Tomb Robber", "Leather Case", 1, true);
			
			bot.Player.Join("necrocavern");
			bot.Player.HuntForItem("Shadow Imp", "Shadowstone Sharpener", 1, true);
			
			bot.Player.Join("vordredboss");
			bot.Player.HuntForItem("Shadow Vordred", "Shadow Lacquer Finish", 1, true);
			
			bot.Player.Join("anders");
			bot.Player.HuntForItem("Copper Sky Pirate", "Copper Awl", 1, true);
			
			bot.Quests.EnsureComplete(2164);
			bot.Wait.ForDrop("DoomSoldier Weapon Kit");
			bot.Player.Pickup("DoomSoldier Weapon Kit");
		}
	}
}