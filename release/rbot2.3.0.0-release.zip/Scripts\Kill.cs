using RBot;
using System;

public class Script {

    public void ScriptMain(ScriptInterface bot){
        bot.Skills.Add(1, 2f);
        bot.Skills.Add(2, 2f);
        bot.Skills.Add(3, 2f);
        bot.Skills.Add(4, 2f);

        bot.Skills.StartTimer();

        while(!bot.ShouldExit()){
            bot.Player.Kill("*");
        }
    }
}