using RBot;
 
public class Script {
 
    public void ScriptMain(ScriptInterface bot){
        bot.Options.SafeTimings = true;
        bot.Options.RestPackets = true;
 
        SkillDef def = new SkillDef();
        def.Load("Skills/VoidHighLord.xml");
        bot.Skills.OverrideSkills = def;
        bot.Skills.StartTimer();

        bot.Player.Join("battleunderb");
        
        while(!bot.ShouldExit()){
        	bot.Player.Kill("*");
        }
    }
}