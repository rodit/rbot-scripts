using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Skills.StartTimer();
		ManaGolem(bot);
	}
	
	public void ManaGolem(ScriptInterface bot){
		bot.Player.LoadBank();
        bot.Inventory.BankAllCoinItems();
        
        bot.Bank.ToInventory("Voucher of Nulgath (non-mem)");
        bot.Bank.ToInventory("Voucher of Nulgath");
        bot.Bank.ToInventory("Gem of Nulgath");
        bot.Bank.ToInventory("Dark Crystal Shard");
        bot.Bank.ToInventory("Tainted Gem");
        bot.Bank.ToInventory("Totem of Nulgath");
        bot.Bank.ToInventory("Diamond of Nulgath");
        bot.Bank.ToInventory("Unidentified 10");
        bot.Bank.ToInventory("Unidentified 13");
        
        bot.Quests.EnsureAccept(2566);
        bot.Player.Join("gilead");
        bot.Player.HuntForItem("Mana Elemental", "Charged Mana Energy for Nulgath", 1, true);
        bot.Player.Join("elemental");
        bot.Player.HuntForItem("Mana Golem", "Mana Energy for Nulgath", 1, true);
        bot.Player.AddTempItem(6135, 100000);
        bot.Player.AddTempItem(15385, 100000);
        bot.Player.Jump("Enter", "Spawn");
        
        int accum = 0;
        while(!bot.ShouldExit()){
            bot.Quests.EnsureAccept(2566);
            bot.Quests.EnsureComplete(2566);
            
            accum++;
            if(accum == 10){
            	accum = 0;
            	bot.Player.Pickup("Unidentified 13", "Voucher of Nulgath (non-mem)", "Voucher of Nulgath", "Gem of Nulgath", "Dark Crystal Shard", "Tainted Gem", "Totem of Nulgath", "Unidentified 10", "Diamond of Nulgath");
            	bot.Player.RejectExcept("Unidentified 13", "Voucher of Nulgath (non-mem)", "Voucher of Nulgath", "Gem of Nulgath", "Dark Crystal Shard", "Tainted Gem", "Totem of Nulgath", "Unidentified 10", "Diamond of Nulgath");
            }
		}
    }
}
