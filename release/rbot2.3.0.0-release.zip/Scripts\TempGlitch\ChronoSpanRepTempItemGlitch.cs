using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.Join("thespan");
		bot.Quests.EnsureAccept(2205);
		bot.Player.HuntForItem("Minx Fairy", "Fairy Fluff", 1, true);
		bot.Player.HuntForItem("Sneak", "Sneak Spit Nitro", 1, true);
		bot.Player.HuntForItem("Moglin Ghost", "Spectre Petre", 1, true);
		bot.Player.AddTempItem(12785, 100000);
		bot.Player.AddTempItem(12786, 100000);
		bot.Player.AddTempItem(12787, 100000);
		bot.Player.Jump("Spawn", "Enter");
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(2205);
			bot.Quests.EnsureComplete(2205);
		}
	}
}
