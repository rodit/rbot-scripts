using RBot;
using System;

public class Script{

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.Join("prison");
		bot.Player.HuntForItem("King Alteon's Knight", "King's Guard Slain", 25, true);
	}
}