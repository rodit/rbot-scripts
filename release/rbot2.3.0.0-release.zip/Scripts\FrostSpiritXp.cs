using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Skills.StartTimer();
		
		bot.Player.JoinGlitched("icestormarena");
		
		while(!bot.ShouldExit()){
			bot.Player.Hunt("Frost Spirit");
			if(bot.Player.Health < bot.Player.MaxHealth * 0.2f){
				bot.Player.Jump(bot.Player.Cell, bot.Player.Pad);
				bot.Player.Rest();
				bot.Wait.ForTrue(() => bot.Player.Health >= bot.Player.MaxHealth * 0.2f);
			}
		}
	}
}
