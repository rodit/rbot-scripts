using RBot;
using RBot.Strategy;
using System.Windows.Forms;

public class Script
{

    public void ScriptMain(ScriptInterface bot)
    {
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		
		bot.Skills.StartTimer();
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Dark Makai")
				.Item("Defeated Makai")
				.Quantity(50)
				.Navigator(new TercessuinotlimNavigator())
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Escherion")
				.Item("Escherion's Chain")
				.Room("escherion")
				.Build());
				
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("O-Dokuro's Head")
				.Item("O-dokuro's Tooth")
				.Room("yokaiwar")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Vath")
				.Item("Strand of Vath's Hair")
				.Room("stalagbite")
				.Build());
				
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Aracara")
				.Item("Aracara's Fang")
				.Room("faerie")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Hydra Head")
				.Item("Hydra Scale")
				.Room("hydra")
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Monster("Tibicenas")
				.Item("Tibicenas' Chain")
				.Temp()
				.Room("djinn")
				.Build());
		
		bot.Strategies.Register(
		new QuestStrategy.Builder()
				.Quest(570)
				.Item("Dark Crystal Shard")
				.Build());
		
		SmartBot.ObtainItem(bot, "Dark Crystal Shard", 251);
    }
    
	public class TercessuinotlimNavigator : Navigator
	{
		public override void Navigate(ScriptInterface bot){
	        bot.Player.Join("citadel", "m22", "Right");
            bot.Player.Join("tercessuinotlim", "Enter", "Spawn");
		}
    }
}
