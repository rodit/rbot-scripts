using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Skills.StartTimer();
		
		bot.Player.LoadBank();
		bot.Inventory.BankAllCoinItems();
		bot.Bank.ToInventory("Essence of Nulgath");
		bot.Bank.ToInventory("Totem of Nulgath");
		
		if(bot.Map.Name != "tercessuinotlim"){
	        bot.Player.Join("citadel");
			bot.Player.Jump("m22", "Right");
            bot.Player.Join("tercessuinotlim", "Enter", "Spawn");
        }
		
		while(!bot.Inventory.Contains("Totem of Nulgath", 30) && !bot.ShouldExit()){
			bot.Quests.EnsureAccept(726);
			
			bot.Player.HuntForItem("Dark Makai", "Essence of Nulgath", 100);
			
			bot.Player.HuntForItem("Tainted Elemental", "Lesser Tainted Core", 1, true);
			
			bot.Quests.EnsureComplete(726);
			
			bot.Wait.ForPickup("Totem of Nulgath");
			bot.Player.Pickup("Totem of Nulgath");
		}
	}
}
