using RBot;
using System.Windows.Forms;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.RestPackets = true;
		bot.Options.SafeTimings = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		bot.Options.HuntDelay = 2500;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Elders' Blood");
		
		bot.Quests.EnsureAccept(802);
		
		if(bot.Quests.IsDailyComplete(802))
			MessageBox.Show("Daily quest has already been completed!");
		else{
			
			bot.Player.Join("arcangrove");
			
			bot.Player.HuntForItem("Gorillaphant", "Slain Gorillaphant", 50, true);
			
			bot.Quests.EnsureComplete(802);
			
			bot.Wait.ForDrop("Elders' Blood");
			bot.Player.Pickup("Elders' Blood");
		}
	}
}
