using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Skills.StartTimer();
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Options.HuntPriority = HuntPriorities.LowHP;
		
		bot.Player.LoadBank();
		bot.Runtime.Require("Dark Energy");
		
		bot.Player.Join("poisonforest");
		bot.Player.HuntForItem("Traitor Knight|Traitor Lieutenant", "Dark Energy", 10000);
	}
}
