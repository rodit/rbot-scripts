using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.Join("arcangrove");
		bot.Quests.EnsureAccept(795);
		bot.Player.HuntForItem("Gorillaphant", "Slain Gorillaphant", 1, true);
		bot.Player.AddTempItem(5574, 100000);
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(795);
			bot.Quests.EnsureComplete(795);
		}
	}
}
