using RBot;
using RBot.Strategy;
using System.Windows.Forms;

public class Script
{

    public void ScriptMain(ScriptInterface bot)
    {
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		bot.Options.ExitCombatBeforeQuest = true;
		
		bot.Player.LoadBank();
		
		bot.Skills.StartTimer();
		
		bot.Bank.ToInventory("Unidentified 13");
		
		//Shadow Lich
		bot.Strategies.Register(
		new BuyStrategy.Builder()
				.Item("Shadow Lich")
				.Cost(50000)
				.Shop(89)
				.Build());
		
		//Dragonfire of Nulgath
		bot.Strategies.Register(
		new QuestStrategy.Builder()
				.Item("Dragonfire of Nulgath")
				.Quest(765)
				.Reward(1316)
				.Build());
		
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Nulgath Rune 4")
				.Monster("Skull Warrior")
				.Room("underworld")
				.Build());
				
		//New worlds new opportunities
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Slugfit Horn")
				.Temp()
				.Monster("Slugfit")
				.Room("mobius")
				.Build());
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Makai Fang")
				.Temp()
				.Monster("Dark Makai")
				.Navigator(new TercessuinotlimNavigator())
				.Build());
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Imp Flame")
				.Temp()
				.Monster("Fire Imp")
				.Room("mobius")
				.Build());
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Cyclops Horn")
				.Temp()
				.Monster("Cyclops Warlord")
				.Room("faerie")
				.Build());
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Wereboar Tusk")
				.Temp()
				.Monster("Big Bad Boar")
				.Room("greenguardwest")
				.Build());
		
		bot.Strategies.Register(new NulgathStrategy("Totem of Nulgath", "Diamond of Nulgath", 6697));
		
		
		//Supplies to spin the wheel
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Escherion's Helm")
				.Monster("Escherion")
				.Room("escherion")
				.Build());
		//Unidentified 19
		bot.Strategies.Register(new NulgathStrategy("Unidentified 19", "Escherion's Helm", 555));
		
		//Essence of nulgath
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Essence of Nulgath")
				.Monster("Dark Makai")
				.Navigator(new TercessuinotlimNavigator())
				.Build());
		
		//Mystic Tribal Sword
		bot.Strategies.Register(
		new BuyStrategy.Builder()
				.Item("Mystic Tribal Sword")
				.Cost(6000)
				.Shop(214)
				.Build());
		
		//Doomatter
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Doomatter")
				.Monsters("Vordred", "Ultra Vordred", "Enraged Vordred")
				.Room("vordredboss")
				.Build());
				
		//Chaoroot
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Chaoroot")
				.Monster("Hydra Head")
				.Room("hydra")
				.Build());
				
		//Necrot
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Necrot")
				.Monster("Skeleton Fighter")
				.Room("deathsrealm")
				.Build());
		
		//Archfiend's favor
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Archfiend's Favor")
				.Monsters("Blade Master", "Skull Warrior", "Legion Fenrir", "Undead Bruiser", "Undead Infantry")
				.Pickup("King Klunk's Crown")
				.Room("underworld")
				.Build());
				
		//Mortality Cape of Revontheus
		bot.Strategies.Register(
		new MergeStrategy.Builder()
				.Item("Mortality Cape of Revontheus")
				.Cost(6000)
				.Shop(452)
				.ItemRequirement("Archfiend's Favor", 35)
				.Build());
				
		//King Klunk's Crown
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("King Klunk's Crown")
				.Monsters("Laken", "Legion Fenrir")
				.Pickup("Archfiend's Favor")
				.Room("underworld")
				.Build());
				
		//Facebreaker of Nulgath (Dagger)
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Golden Shadow Breaker")
				.Monster("Grand Inquisitor")
				.Room("citadel")
				.Build());
				
		bot.Strategies.Register(
		new DropStrategy.Builder()
				.Item("Shadow Terror Axe")
				.Monster("Bone Terror")
				.Room("battleundera")
				.Build());
		
		bot.Strategies.Register(new NulgathStrategy("Unidentified 13", "Diamond of Nulgath", 6697));
		bot.Strategies.Register(new NulgathStrategy("Tainted Gem", "Diamond of Nulgath", 6697));
		bot.Strategies.Register(new NulgathStrategy("Dark Crystal Shard", "Diamond of Nulgath", 6697));
		bot.Strategies.Register(new NulgathStrategy("Diamond of Nulgath", "Diamond of Nulgath", 6697));
		
		bot.Strategies.Register(
		new QuestStrategy.Builder()
				.Item("Facebreaker of Nulgath")
				.AlsoObtain("SightBlinder Axe of Nulgath")
				.Quest(3046)
				.Build());
		
		bot.Strategies.Register(
		new QuestStrategy.Builder()
				.Item("Unidentified 34")
				.Quest(5258)
				.Build());
				
		SmartBot.ObtainItem(bot, "Unidentified 34", 100);
    }
    
	public class NulgathStrategy : QuestStrategy
	{
		public string NulgathItem { get; set; }
		public string WaitItem { get; set; }
		
		public NulgathStrategy(string nitem, string wait, int quest){
			Item = nitem;
			NulgathItem = nitem;
			WaitItem = wait;
			Quest = quest;
		}
	
    	public override void Obtain(ScriptInterface bot, int quantity)
    	{
    		Item = WaitItem;
    		Drops.Clear();
    		Drops.Add("Diamond of Nulgath");
    		Drops.Add("Dark Crystal Shard");
    		Drops.Add("Unidentified 13");
    		Drops.Add("Tainted Gem");
    		Drops.Add("Voucher of Nulgath");
    		Drops.Add("Voucher of Nulgath (non-mem)");
    		Drops.Add("Totem of Nulgath");
    		Drops.Add("Gem of Nulgath");
    		Drops.Add("Blood Gem of the Archfiend");
    		Drops.Add("Archfiend's Birthday Cake");
    		Drops.Add("Fiendish Caladbolg");
    		foreach(string item in Drops)
    			bot.Bank.ToInventory(item);
    		while(!bot.Inventory.Contains(NulgathItem, quantity))
    			base.Obtain(bot);
    	}
    }
    
    public class TercessuinotlimNavigator : Navigator
	{
		public override void Navigate(ScriptInterface bot){
	        bot.Player.Join("citadel", "m22", "Right");
            bot.Player.Join("tercessuinotlim", "Enter", "Spawn");
		}
    }
}
