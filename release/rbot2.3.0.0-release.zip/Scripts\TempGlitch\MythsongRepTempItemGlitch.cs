using RBot;

public class Script {

	public void ScriptMain(ScriptInterface bot){
		bot.Options.SafeTimings = true;
		bot.Options.RestPackets = true;
		
		bot.Player.Join("beehive");
		bot.Quests.EnsureAccept(4829);
		bot.Player.HuntForItem("Stinger", "Honey Gathered", 1, true);
		bot.Player.AddTempItem(33572, 100000);
		while(!bot.ShouldExit()){
			bot.Quests.EnsureAccept(4829);
			bot.Quests.EnsureComplete(4829);
		}
	}
}
